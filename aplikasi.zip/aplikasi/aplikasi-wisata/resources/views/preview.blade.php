<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Preview</title>
</head>
<body>
    <h1>Wisata Maros</h1>
    <p>id : {{$id}}</p>
    <p>Nama : {{$pelanggan->nama_pelanggan}}</p>
    <p>Tanggal Berangkat : {{$pelanggan->tanggal_berangkat}}</p>
    <p>Jam Berangkat : {{$pelanggan->jam_berangkat}} WITA</p>
    <table border="1">
        <tr>
            <td>kunjungan</td>
            <td>Nama Tempat</td>
            <td>deskripsi</td>
            <td>Durasi dilokasi + Durasi perjalanan</td>
            <td>Jarak Kantor</td>
            <td>biaya dilokasi</td>
        </tr>
        @foreach ($wisata as $item)
        <tr>
            <td>{{$urutan=1+$urutan}}</td>
            <td>{{$daftarTempats->find($item)->nama_tempat}}</td>
            <td>{{$daftarTempats->find($item)->deskripsi}}</td>
            <td>{{$daftarTempats->find($item)->durasi_dilokasi}} Menit</td>
            <td>{{$daftarTempats->find($item)->jarak_kantor}} KM</td>
            <td>Rp. {{number_format($daftarTempats->find($item)->biaya_lokasi, 0, ".", ".")}}</td>
            <input type="hidden" value="{{$biayas=$biayas+$daftarTempats->find($item)->biaya_lokasi}}">
            <input type="hidden" value="{{$totalJam = $totalJam + $daftarTempats->find($item)->durasi_dilokasi}}">
        </tr>
        @endforeach
        </table>
    <p>Perjalan anda selesai kira-kira Jam : {{date('H:i', strtotime('+'.$totalJam. 'minutes',$jamBerangkat))}} WITA </p>
    <p>Total Biaya : Rp. {{number_format($biayas, 0, ".", ".")}}</p>
</body>
</html>