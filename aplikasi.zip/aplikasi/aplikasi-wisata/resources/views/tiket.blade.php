@extends('layouts')
@section('content')
<form action="{{route('simpanTiket')}}" method="POST">
    {{ csrf_field() }}
    <p>Nama : {{$rahim=$data->namaPelanggan}}</p>
    <input type="hidden" name="namaPelanggan" value="{{$data->namaPelanggan}}">
    <p>Tanggal Berangkat : {{$tanggal}}</p>
    <input type="hidden" name="tanggalBerangkat" value="{{$tanggal}}">
    <p>Jam Berangkat : {{$data->jamBerangkat}} WITA</p>
    <input type="hidden" name="jamBerangkat"  value="{{$data->jamBerangkat}}">
    <table border="1">
        <tr>
            <td>kunjungan</td>
            <td>Nama Tempat</td>
            <td>deskripsi</td>
            <td>Durasi dilokasi</td>
            <td>Jarak Kantor</td>
            <td>biaya dilokasi</td>
        </tr>
        @foreach ($data->tempatWisata as $item)
        <tr>
            <td>{{$urutan=1+$urutan}}</td>
            <td>{{$daftarTempats->find($item)->nama_tempat}}</td>
            <td>{{$daftarTempats->find($item)->deskripsi}}</td>
            <td>{{$daftarTempats->find($item)->durasi_dilokasi}} Menit</td>
            <td>{{$daftarTempats->find($item)->jarak_kantor}} KM</td>
            <td>Rp. {{number_format($daftarTempats->find($item)->biaya_lokasi, 0, ".", ".")}}</td>
            <input type="hidden" name="wisata" value="{{$wisata}}">
            <input type="hidden" name="biayas" value="{{$biayas=$biayas+$daftarTempats->find($item)->biaya_lokasi}}">
            <input type="hidden" value="{{$totalJam = $totalJam + $daftarTempats->find($item)->durasi_dilokasi}}">
        </tr>
        @endforeach
    </table>
    <p>Perjalan anda selesai kira-kira Jam : {{date('H:i', strtotime('+'.$totalJam. 'minutes',$jamBerangkat))}} WITA </p>
    <p>Total Biaya : Rp. {{number_format($biayas, 0, ".", ".")}}</p>
    <button>Setuju dan Cetak</button>
</form>
@endsection