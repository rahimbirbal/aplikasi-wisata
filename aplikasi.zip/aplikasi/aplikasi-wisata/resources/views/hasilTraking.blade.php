<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>hasil Traking</title>
</head>
<body>
    <a href="{{route('traking')}}">Kembali</a>
    <h2>Peta Wisata</h2>
    <img src="{{asset('img/peta.png')}}" alt="" style="width: 1000px">
    <form action="{{route('cetakTraking')}}" method="POST">
    {{ csrf_field() }}
    <p>ID : {{$pelanggan->id}}</p>
    <input type="hidden" name="idTiket" value="{{$idTiket=$pelanggan->id}}">
    <p>Nama : {{$pelanggan->nama_pelanggan}}</p>
    <p>Tanggal Berangkat : {{$pelanggan->tanggal_berangkat}}</p>
    <p>Jam Berangkat : {{$pelanggan->jam_berangkat}} WITA</p>
    <table border="1">
        <tr>
            <td>kunjungan</td>
            <td>Nama Tempat</td>
            <td>deskripsi</td>
            <td>Durasi dilokasi + Durasi perjalanan</td>
            <td>Jarak Kantor</td>
            <td>biaya dilokasi</td>
        </tr>
        @foreach ($tempatWisata as $item)
        <tr>
            <td>{{$urutan=1+$urutan}}</td>
            <td>{{$daftarTempat->find($item)->nama_tempat}}</td>
            <td>{{$daftarTempat->find($item)->deskripsi}}</td>
            <td>{{$daftarTempat->find($item)->durasi_dilokasi}} Menit</td>
            <td>{{$daftarTempat->find($item)->jarak_kantor}} KM</td>
            <td>Rp. {{number_format($daftarTempat->find($item)->biaya_lokasi, 0, ".", ".")}}</td>
            <input type="hidden" value="{{$totalBiaya = $totalBiaya + $daftarTempat->find($item)->biaya_lokasi}}">
            <input type="hidden" value="{{$totalJam = $totalJam + $daftarTempat->find($item)->durasi_dilokasi}}">
        </tr>
        @endforeach
    </table>
    <p>Perjalan anda selesai kira-kira Jam : {{date('H:i', strtotime('+'.$totalJam. 'minutes',$jamBerangkat))}} WITA</p>
    <p>Total Biaya : Rp. {{number_format($totalBiaya, 0, ".", ".")}}</p>
    <button type="submit">Cetak</button>
    </form>
</body>
</html>