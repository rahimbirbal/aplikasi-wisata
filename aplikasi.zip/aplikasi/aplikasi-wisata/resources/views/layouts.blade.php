<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>aplikasi wisata</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Aplikasi wisata</h1>
    <a href="{{route('index')}}">Pesan Mobil Wisata</a><br>
    <a href="{{route('daftarWisata')}}">Daftar Tempat wisata</a><br>
    <a href="{{route('traking')}}">cek tiket</a><br>
    @yield('content')
</body>
</html>