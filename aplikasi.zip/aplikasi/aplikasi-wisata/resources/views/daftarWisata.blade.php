@extends('layouts')
@section('content')

<h1>Daftar Wisata</h1>
<table border="1">
    <tr>
        <td>nomor</td>
        <td>Nama wisata</td>
        <td>deskripsi</td>
        <td>jarak dari kantor</td>
        <td>Biaya dilokasi</td>
    </tr>
    @foreach ($wisatas as $item)
    <tr>
    <td>{{$item->id}}</td>
    <td>{{$item->nama_tempat}}</td>
    <td>{{$item->deskripsi}}</td>
    <td>{{$item->jarak_kantor}} KM</td>
    <td>Rp. {{number_format($item->biaya_lokasi, 0, ".", ".")}}</td>
</tr>
    @endforeach
</table>
    
@endsection