@extends('layouts')
@section('content')
<h2>Peta Wisata</h2>
<img src="{{asset('img/peta.png')}}" alt="" style="width: 1000px">
<h2>Buat Tiket</h2>
<form action="{{route('tiket')}}" method="POST">
    {{csrf_field()}}
    <p>Nama</p>
    <input type="text" name="namaPelanggan" value="{{old('namaPelanggan')}}">
        @if ($errors->has('namaPelanggan'))
            {{$errors->first('namaPelanggan')}}
        @endif
    <p>tanggal keberangkatan</p>
    <input type="date" name="tanggalBerangkat" value="{{old('tanggalBerangkat')}}">
        @if ($errors->has('tanggalBerangkat'))
            {{$errors->first('tanggalBerangkat')}}
        @endif
    <p>jam keberangkatan</p>
    <input type="time" name="jamBerangkat" value="{{old('jamBerangkat')}}">
        @if ($errors->has('jamBerangkat'))
            {{$errors->first('jamBerangkat')}}
        @endif
    <p>Tempat wisata yang ingin dikunjungi</p>
        @foreach ($daftarTempats as $item)
            <input name="tempatWisata[]" value="{{$item->id}}" type="checkbox">{{$item->nama_tempat}}<br>
        @endforeach
    <button>Next</button>
</form>
@endsection
    