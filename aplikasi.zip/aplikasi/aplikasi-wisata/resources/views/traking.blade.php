@extends('layouts')
@section('content')
<form action="{{route('hasilTraking')}}" method="POST">
    {{ csrf_field() }}
    Masukkan ID tiket :
    <input type="text" name="idTiket">
    <button type="submit">Cari</button>
</form>
@endsection