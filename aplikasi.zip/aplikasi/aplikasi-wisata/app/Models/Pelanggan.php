<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pelanggan extends Model
{
    use HasFactory;
    protected $table='pelanggan';
    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'nama_pelanggan',
        'tanggal_berangkat',
        'jam_berangkat',
        'daftar_wisata',
        'total_biaya'
    ];

    /**
     * @var array
     */
    protected $hidden = [

    ];

    
}
