<?php

namespace App\Http\Controllers;
use App\Models\DaftarTempat;
use App\Models\Pelanggan;
use Barryvdh\DomPDF\PDF as DomPDFPDF;
use Dompdf\Adapter\PDFLib;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use PDF;


class daftarController extends Controller
{
    public function index(){
        $daftarTempats=DaftarTempat::all();
        return view('daftar',compact('daftarTempats'));
    }

    public function postindex(Request $request){
        $this->validate($request,[
            'namaPelanggan' => 'required|min:4',
            'tanggalBerangkat' => 'required',
            'jamBerangkat' => 'required',
            'tempatWisata' => 'required',
        ]);
        $data=$request;
        $daftarTempats = DaftarTempat::all();
        $tanggal=date('d F Y', strtotime($request->tanggalBerangkat));
        $urutan=0;
        $biayas=0;
        $wisata = implode(",", $request->tempatWisata);
        $jamBerangkat = strtotime($request->jamBerangkat);
        $totalJam=0;
        return view('tiket',compact('data','daftarTempats','tanggal','urutan','biayas','wisata','jamBerangkat','totalJam'));
    }

    public function simpanTiket(Request $request){
        $id = mt_rand(1000000, 9999999);
        Pelanggan::create([
            'id' => $id,
            'nama_pelanggan' => $request->namaPelanggan,
            'tanggal_berangkat' => $request->tanggalBerangkat,
            'jam_berangkat' => $request->jamBerangkat,
            'daftar_wisata' => $request->wisata,
            'total_biaya' => $request->biayas
        ]);
        $pelanggan = Pelanggan::where('id', $id)->first();
        $wisata = explode(",", $pelanggan->daftar_wisata);
        $jamBerangkat = strtotime($pelanggan->jam_berangkat);
        $totalJam=0;
        $urutan=0;
        $daftarTempats = DaftarTempat::all();
        $biayas=0;
        $pdf = PDF::loadView('preview',compact('id','pelanggan','wisata','jamBerangkat','totalJam','biayas','totalJam','daftarTempats','urutan'));
        return $pdf->download('cetakpdf.pdf');
    }

    // public function tiketsukses(Request $request){
    //     $data = $request;
    //     $daftarTempats = DaftarTempat::all();
    //     $tanggal=date('d F Y', strtotime($request->tanggalBerangkat));
    //     $urutan=0;
    //     $biayas=0;
    //     $sebelumWisata = explode(",",$request->tempatWisata);
    //     $wisata = implode(",", $sebelumWisata);
    //     $jamBerangkat = strtotime($request->jamBerangkat);
    //     $totalJam=0;
    //     return dd($data);
    //     // return view('preview',compact('data','daftarTempats','tanggal','urutan','biayas','wisata','jamBerangkat','totalJam'));
    // }

    // public function pdf(){
    //     $inie=0;
    //     $pdf = PDF::loadView('cetakpdf');
    //     return $pdf->download('cetakpdf.pdf');
    // }
}
