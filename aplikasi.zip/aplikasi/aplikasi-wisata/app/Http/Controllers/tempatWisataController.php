<?php

namespace App\Http\Controllers;
use App\Models\DaftarTempat;

use Illuminate\Http\Request;

class tempatWisataController extends Controller
{
    public function index(){
        $wisatas = DaftarTempat::all();
        return view('daftarWisata',compact('wisatas'));
    }
}
