<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pelanggan;
use App\Models\DaftarTempat;
use Carbon\Carbon;
use PDF;
class trakingController extends Controller
{
    public function traking(){
        return view('traking');
    }

    public function hasilTraking(Request $request){
        $idTiket = $request->idTiket;
        $daftarTempat = DaftarTempat::all();
        $pelanggan = Pelanggan::where('id', $idTiket)->first();
        $tempatWisata = explode(",",$pelanggan->daftar_wisata);
        $urutan=0;
        $totalBiaya = 0;
        $jamBerangkat = strtotime($pelanggan->jam_berangkat);
        $totalJam=0;
        return view('hasilTraking',compact('pelanggan','tempatWisata','urutan','daftarTempat','totalBiaya','totalJam','jamBerangkat'));
    }

    public function cetakTraking(Request $request){
        $id = $request->idTiket;
        $pelanggan = Pelanggan::where('id', $id)->first();
        $wisata = explode(",", $pelanggan->daftar_wisata);
        $jamBerangkat = strtotime($pelanggan->jam_berangkat);
        $totalJam=0;
        $urutan=0;
        $daftarTempats = DaftarTempat::all();
        $biayas=0;
        $pdf = PDF::loadView('preview',compact('id','pelanggan','wisata','jamBerangkat','totalJam','biayas','totalJam','daftarTempats','urutan'));
        return $pdf->download('cetakpdf.pdf');
    }
}
