<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('hasilTraking')); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    Masukkan ID tiket :
    <input type="text" name="idTiket">
    <button type="submit">Cari</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abd.rahimsaleh/iFolder/aplikasi-wisata/resources/views/traking.blade.php ENDPATH**/ ?>