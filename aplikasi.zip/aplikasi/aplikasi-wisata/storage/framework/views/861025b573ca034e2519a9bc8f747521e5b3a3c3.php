<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Preview</title>
</head>
<body>
    <h1>Wisata Maros</h1>
    <p>id : <?php echo e($id); ?></p>
    <p>Nama : <?php echo e($pelanggan->nama_pelanggan); ?></p>
    <p>Tanggal Berangkat : <?php echo e($pelanggan->tanggal_berangkat); ?></p>
    <p>Jam Berangkat : <?php echo e($pelanggan->jam_berangkat); ?> WITA</p>
    <table border="1">
        <tr>
            <td>kunjungan</td>
            <td>Nama Tempat</td>
            <td>deskripsi</td>
            <td>Durasi dilokasi + Durasi perjalanan</td>
            <td>Jarak Kantor</td>
            <td>biaya dilokasi</td>
        </tr>
        <?php $__currentLoopData = $wisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($urutan=1+$urutan); ?></td>
            <td><?php echo e($daftarTempats->find($item)->nama_tempat); ?></td>
            <td><?php echo e($daftarTempats->find($item)->deskripsi); ?></td>
            <td><?php echo e($daftarTempats->find($item)->durasi_dilokasi); ?> Menit</td>
            <td><?php echo e($daftarTempats->find($item)->jarak_kantor); ?> KM</td>
            <td>Rp. <?php echo e(number_format($daftarTempats->find($item)->biaya_lokasi, 0, ".", ".")); ?></td>
            <input type="hidden" value="<?php echo e($biayas=$biayas+$daftarTempats->find($item)->biaya_lokasi); ?>">
            <input type="hidden" value="<?php echo e($totalJam = $totalJam + $daftarTempats->find($item)->durasi_dilokasi); ?>">
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <p>Perjalan anda selesai kira-kira Jam : <?php echo e(date('H:i', strtotime('+'.$totalJam. 'minutes',$jamBerangkat))); ?> WITA </p>
    <p>Total Biaya : Rp. <?php echo e(number_format($biayas, 0, ".", ".")); ?></p>
</body>
</html><?php /**PATH /Users/abd.rahimsaleh/iFolder/aplikasi-wisata/resources/views/preview.blade.php ENDPATH**/ ?>