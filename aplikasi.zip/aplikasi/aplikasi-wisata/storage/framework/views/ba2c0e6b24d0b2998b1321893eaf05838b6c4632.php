<?php $__env->startSection('content'); ?>

<h1>Daftar Wisata</h1>
<table border="1">
    <tr>
        <td>nomor</td>
        <td>Nama wisata</td>
        <td>deskripsi</td>
        <td>jarak dari kantor</td>
        <td>Biaya dilokasi</td>
    </tr>
    <?php $__currentLoopData = $wisatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($item->id); ?></td>
    <td><?php echo e($item->nama_tempat); ?></td>
    <td><?php echo e($item->deskripsi); ?></td>
    <td><?php echo e($item->jarak_kantor); ?> KM</td>
    <td>Rp. <?php echo e(number_format($item->biaya_lokasi, 0, ".", ".")); ?></td>
</tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abd.rahimsaleh/iFolder/aplikasi-wisata/resources/views/daftarWisata.blade.php ENDPATH**/ ?>