<?php $__env->startSection('content'); ?>
<h2>Peta Wisata</h2>
<img src="<?php echo e(asset('img/peta.png')); ?>" alt="" style="width: 1000px">
<h2>Buat Tiket</h2>
<form action="<?php echo e(route('tiket')); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <p>Nama</p>
    <input type="text" name="namaPelanggan" value="<?php echo e(old('namaPelanggan')); ?>">
        <?php if($errors->has('namaPelanggan')): ?>
            <?php echo e($errors->first('namaPelanggan')); ?>

        <?php endif; ?>
    <p>tanggal keberangkatan</p>
    <input type="date" name="tanggalBerangkat" value="<?php echo e(old('tanggalBerangkat')); ?>">
        <?php if($errors->has('tanggalBerangkat')): ?>
            <?php echo e($errors->first('tanggalBerangkat')); ?>

        <?php endif; ?>
    <p>jam keberangkatan</p>
    <input type="time" name="jamBerangkat" value="<?php echo e(old('jamBerangkat')); ?>">
        <?php if($errors->has('jamBerangkat')): ?>
            <?php echo e($errors->first('jamBerangkat')); ?>

        <?php endif; ?>
    <p>Tempat wisata yang ingin dikunjungi</p>
        <?php $__currentLoopData = $daftarTempats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input name="tempatWisata[]" value="<?php echo e($item->id); ?>" type="checkbox"><?php echo e($item->nama_tempat); ?><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button>Next</button>
</form>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abd.rahimsaleh/iFolder/aplikasi-wisata/resources/views/daftar.blade.php ENDPATH**/ ?>