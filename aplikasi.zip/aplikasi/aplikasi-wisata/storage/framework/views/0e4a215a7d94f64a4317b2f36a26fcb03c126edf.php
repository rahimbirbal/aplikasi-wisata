<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('simpanTiket')); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <p>Nama : <?php echo e($rahim=$data->namaPelanggan); ?></p>
    <input type="hidden" name="namaPelanggan" value="<?php echo e($data->namaPelanggan); ?>">
    <p>Tanggal Berangkat : <?php echo e($tanggal); ?></p>
    <input type="hidden" name="tanggalBerangkat" value="<?php echo e($tanggal); ?>">
    <p>Jam Berangkat : <?php echo e($data->jamBerangkat); ?> WITA</p>
    <input type="hidden" name="jamBerangkat"  value="<?php echo e($data->jamBerangkat); ?>">
    <table border="1">
        <tr>
            <td>kunjungan</td>
            <td>Nama Tempat</td>
            <td>deskripsi</td>
            <td>Durasi dilokasi</td>
            <td>Jarak Kantor</td>
            <td>biaya dilokasi</td>
        </tr>
        <?php $__currentLoopData = $data->tempatWisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($urutan=1+$urutan); ?></td>
            <td><?php echo e($daftarTempats->find($item)->nama_tempat); ?></td>
            <td><?php echo e($daftarTempats->find($item)->deskripsi); ?></td>
            <td><?php echo e($daftarTempats->find($item)->durasi_dilokasi); ?> Menit</td>
            <td><?php echo e($daftarTempats->find($item)->jarak_kantor); ?> KM</td>
            <td>Rp. <?php echo e(number_format($daftarTempats->find($item)->biaya_lokasi, 0, ".", ".")); ?></td>
            <input type="hidden" name="wisata" value="<?php echo e($wisata); ?>">
            <input type="hidden" name="biayas" value="<?php echo e($biayas=$biayas+$daftarTempats->find($item)->biaya_lokasi); ?>">
            <input type="hidden" value="<?php echo e($totalJam = $totalJam + $daftarTempats->find($item)->durasi_dilokasi); ?>">
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <p>Perjalan anda selesai kira-kira Jam : <?php echo e(date('H:i', strtotime('+'.$totalJam. 'minutes',$jamBerangkat))); ?> WITA </p>
    <p>Total Biaya : Rp. <?php echo e(number_format($biayas, 0, ".", ".")); ?></p>
    <button>Setuju dan Cetak</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abd.rahimsaleh/iFolder/aplikasi-wisata/resources/views/tiket.blade.php ENDPATH**/ ?>