<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\daftarController;
use App\Http\Controllers\tempatWisataController;
use App\Http\Controllers\trakingController;

//daftar controller
Route::get('/', [daftarController::class, 'index'])->name('index');
Route::post('/tiket', [daftarController::class, 'postindex'])->name('tiket');
Route::post('/simpanTiket', [daftarController::class, 'simpanTiket'])->name('simpanTiket');
Route::get('/tiketsukses', [daftarController::class, 'tiketSukses'])->name('sukses');
Route::get('/pdf', [daftarController::class, 'pdf'])->name('print');
//daftar-wisata
Route::get('/daftar-wisata', [tempatWisataController::class, 'index'])->name('daftarWisata');
//traking
Route::get('/traking-tiket', [trakingController::class, 'traking'])->name('traking');
Route::post('/hasil-traking', [trakingController::class, 'hasilTraking'])->name('hasilTraking');
Route::post('/Download', [trakingController::class, 'cetakTraking'])->name('cetakTraking');